[//]: # (<p align="center"><a href="https://dima.nl" target="_blank"><img src="https://th.bing.com/th/id/OIP.a-ppdve8Jg4wDX74g_2TCwAAAA?rs=1&pid=ImgDetMain" width="400" alt="Laravel Logo"></a></p>)


# About SnelEenWebsite API

- Creates websites with directadmin-api
- Uses templates from git

# Setup 
1. ### Run ``install:api`` to run necessary database migrations.
   ``php artisan install:api --passport``

<br>

2. ### Run ``passport:keys`` to generate the encryption keys.
   ``php artisan passport:keys``

<br>

3. ### Create a Client secret for api usage:
   ``php artisan passport:client --password``
   1. fill in correct username from user this token is for

<br>

4. ### Create a User with ``Tinker``
   1. **Start Tinker** <br>
      ``php artisan tinker``<br><br>
   2. **Paste the following** <br>
      ```php
      $user = new User();
      $user->name = 'admin';
      $user->password = Hash::make('qweqweqwe');
      $user->email = 'admin@sneleenwebsite.nl';
      $user->save();
      ```
      
<br>

5. ### In ``/admin`` > ''ApiSettings'' create ``server_user_name``:
   Create entry ``server_user_name`` this has to be the user the domain is registered to.

<br>

6. ### In ``/admin`` > ''ApiSettings'' create ``server_user_password``:
   Create entry ``server_user_password`` this has to be from the user the domain is registered to.

<br>

7. ### In ``/admin`` > ''ApiSettings'' create ``server_domain_path``:
   Create entry ``server_domain_path`` this has to be the path to the domains folder of this user.

<br>

# Authorization 
1. ### Simply send a post request to ``{domain}/oauth/token`` with this required parameters in the ``raw body``.
    after the post request you will get back a bearer_token and a refresh_token
    ```json
    {
        "grant_type": "password",
        "client_id": "{ Passport Client ID }",
        "client_secret": "{ Passport Client Secret }",
        "username": "{ Laravel User Email }",
        "password": "{ Laravel User Password }",
        "scope": "*"
    }
   ```
   be sure to add it to the session to prevent exposing your login details and to prevent the api to flood with inactive bearer-tokens.

<br>
   
2. ### In order to send data to the API you will need to put the token in the request headers
   ```php
   $headers = [
       'Accept' => 'application/json',
       'Content-Type' => 'application/json',
       'Authorization' => 'Bearer { token }'
   ]
   ```
<br>

# Usage 
### Endpoint api/task
with the post request send this in the body and the task will be queued
```json
{
    "Data": {
        "domain":"dima.nl",
        "orderID":"13531",
        "client":"Dion | Dima",
        "email":"dion@dima.nl",
        "phone":"0612345678",
        "template-url":"git.com/dima-support"
    }
}
```

# Endpoints Api 
Endpoint | Type | Resource | Protection
--- | --- | --- | --- 
`oath/token` | **Post** | - | Username, Password, Client ID, Client Secret
`api/task` | **Post** | Task | Bearer
`api/user` | **Get** | User | Login

# Endpoints Web
Endpoint | Protection | Description 
--- | --- | --- 
`/` | **-** | Welcome page 
`/endpoints` | **Login** | Endpoints and documentation 
