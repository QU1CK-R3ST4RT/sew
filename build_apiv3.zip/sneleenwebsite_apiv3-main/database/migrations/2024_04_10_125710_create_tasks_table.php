<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->string('domain');
            $table->unsignedBigInteger('orderID');
            $table->string('client');
            $table->string('email');
            $table->string('phone');
            $table->string('status');
            $table->string('notes');

            $table->string('temp_domain');
            $table->string('letter_type');
            $table->string('template-url');
            $table->string('theme_color');
            $table->string('logo_svg');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tasks');
    }
};
