<?php

use Illuminate\Support\Facades\Route;
use Spatie\LaravelMarkdown\MarkdownRenderer;
use App\Http\Middleware\LoggedIn;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/endpoints', function () {
    return view('Endpoints');
})->middleware('auth');
