<?php

namespace App\Http\Controllers;

use App\Mail\MailService;
use App\Models\ApiSetting;
use App\Models\Task;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Mail\Mailable;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Process;
use phpDocumentor\Reflection\Types\Self_;
use PHPUnit\Util\Json;
use Psr\Container\ContainerExceptionInterface;
use Psr\Container\NotFoundExceptionInterface;

class BuildController extends Controller
{
    private DirectAdminController $DirectAdminController;
    private Task $task;
    private string $log;
    private string $_USER_NAME;
    private string $_USER_PASS;
    private string $_DOMAIN_PATH;

    /**
     * @throws NotFoundExceptionInterface
     * @throws ContainerExceptionInterface
     */
    public function Build(Request $request): \Illuminate\Http\JsonResponse
    {
        set_time_limit(0);

        $this->DirectAdminController = new DirectAdminController();
        $this->Task = new Task();

        $this->log = '';

        $RequestData = $request->all();
        $BuildData = $RequestData["Data"];


//        $result->successful();
//        $result->failed();
//        $result->exitCode();
//        $result->errorOutput();
//        $specificData = $request->input('inputName');
//        return response($result->output());
//        return response()->json($data["Data"]);

        /**
         * Check if needed Variables server_user_name Exist
         * if not throw exception
         *
         * @throws Exception
         **/
        if (!ApiSetting::all()->where('name','=','server_user_name')->first())
            throw new Exception("server_user_name not defined in admin/apisettings");

        /**
         * Check if needed Variables server_user_password Exist
         * if not throw exception
         *
         * @throws Exception
         **/
        if (!ApiSetting::all()->where('name','=','server_user_password')->first())
            throw new Exception("server_user_password not defined in admin/apisettings");

        /**
         * Check if needed Variables server_domain_path Exist
         * if not throw exception
         *
         * @throws Exception
         **/
        if (!ApiSetting::all()->where('name','=','server_domain_path')->first())
            throw new Exception("server_domain_path not defined in admin/apisettings");

        /**
         * Set server_user_name setting as global var
         **/
        $this->_USER_NAME = (string) ApiSetting::all()
            ->where('name','=','server_user_name')
            ->first()->value ?? null;

        /**
         * Set server_user_password setting as global var
         **/
        $this->_USER_PASS = (string) ApiSetting::all()
            ->where('name','=','server_user_password')
            ->first()->value ?? null;

        /**
         * Set server_domain_path setting as global var
         **/
        $this->_DOMAIN_PATH = (string) ApiSetting::all()
            ->where('name','=','server_domain_path')
            ->first()->value ?? null;

        /**
         * Clean user input from malicious attacks or exploits before it is handled
         **/
        $company_name = str_replace("'", "", escapeshellarg( $BuildData["user_defined"]["company_name"] ));
        $company_name = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $company_name));

        /**
         * Check if temp domain already exists. if so add uuid at the end of the company name to avoid other building problems
         **/
        if(Task::all()->where('temp_domain',$company_name.'.dimademo.nl')->first())
            $company_name = $company_name.uuid_generate_md5(null,$company_name);

        /**
         * Add build data to session to keep consistency in names
         **/
        session()->put('domain_name', $company_name.'.dimademo.nl');
        session()->put('database_user', $company_name . '_user1');
        session()->put('database_name', $company_name . '_db');
        session()->put('database_pass', $company_name . '_db_123');
        session()->put('template_url', $BuildData["template-url"]);

        session()->put('site_login', $company_name . '_admin');
        session()->put('site_pass', $this->password_generator(50));

        /**
         * Get build data from session
         **/
        $domain_name = session()->get("domain_name");
        $database_user = session()->get("database_user");
        $database_name = session()->get("database_name");
        $database_pass = session()->get("database_pass");
        $template = session()->get("template_url");

        $site_login = session()->get("site_login");
        $site_pass = session()->get("site_pass");


        dump();
        //assign theme values
        $ThemaKleur = '#fff';
        $LogoLink = 'https://www.dima.nl/themes/dima/images/logo-vector-fixed.svg';
        $LetterType = 'Comic sans';
        $BedrijfsNaam = 'VoorbeeldNaam';

        /**
         * Show current folder (test)
         **/
        $result = Process::run('cd '.$this->_DOMAIN_PATH.' && ls -la');
        dd($result->output());

        /**
         *  Constructor
         **/
//        $this->createDomain($domain_name, $user_name, $user_pass);
//        $this->createDatabase($database_user, $database_name, $database_pass, $user_name, $user_pass);
//        $this->emptyFolder($domain_name, $template, $domain_path);
//        $this->AddTheme($domain_path, $domain_name, $ThemaKleur, $LogoLink, $LetterType, $BedrijfsNaam);
//        $this->composer_commands($domain_path, $domain_name);
//        $this->create_env($domain_path, $domain_name, $database_user, $database_name, $database_pass);
//        $this->inject_sql($domain_path, $domain_name, $database_user, $database_name, $database_pass, $user_name, $user_pass);
//        $this->dev_build($domain_path, $domain_name);
//        $this->npm_build($domain_path, $domain_name);
//        $this->composer_vendor_expose($domain_path, $domain_name);
//        $this->Email();
        return response()->json($BuildData);
    }

    /**
     * Returns a random password
     * @param int $num_chars ammount of caracters
     * @return string
     **/
    public function password_generator(int $num_chars): string
    {
        return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()[]{}<>?', ceil($num_chars / strlen($x)))), 1, $num_chars);
    }

    /**
     *  Creates a domain in root-folder under current user
     * @param string $domain_name
     * @param string $user_name
     * @param string $user_pass
     *
     * @throws Exception
     */
    public function createDomain(string $domain_name, string $user_name, string $user_pass): void
    {
        $sock = $this->DirectAdminController;
        $sock->connect('localhost', 2222);
        $sock->set_login($user_name, $user_pass);
        $sock->set_method('POST');

        /**
         *   Try to add the Domain and show errors on failure
         **/
        try {
            $sock->query('/CMD_DOMAIN',
                array(
                    'action' => 'create',
                    'domain' => $domain_name,
                    'ubandwidth' => 'unlimited',
                    'uquota' => 'unlimited',
                    'ssl' => 'ON',
                    'cgi' => 'ON',
                    'php' => 'ON'
                )
            );
        } catch (Exception $e) {
            throw new Exception($e);
        }

        /**
         * Check if domain was actually created
         */
        $proc1 = Process::run('[ -d '.$this->_DOMAIN_PATH."/".$domain_name.' ] && echo "true"');

        if ($proc1->successful() && $proc1->output()) {
            if (str_contains($proc1->output(),'true')) {
                $this->log.=$proc1->output();
                $this->log.="<p> Succesfully created domain: ".$domain_name."</p>";
                $this->task->save();
            }
        } else { // failed job
            $this->log.=$proc1->output();
            $this->log.="<p> Could not create domain: ".$domain_name."</p>";
            $this->task->notes = $this->log;

            $this->task->save();
        }
    }

    /**
     *  Creates a database based on given parameters
     * @param string $database_user
     * @param string $database_pass
     * @param string $database_name
     * @param string $user_name
     * @param string $user_pass
     **/
    public function createDatabase(string $database_user, string $database_name, string $database_pass, string $user_name, string $user_pass)
    {
        $sock = new HTTPSocket;
        $sock->connect('localhost', 2222);
        $sock->set_login($user_name, $user_pass);
        $sock->set_method('POST');

        /**
         *   Try to add the database and show errors on failure
         **/
        try {
            $sock->query('/CMD_API_DATABASES',
                array(
                    'action' => 'create',
                    'name' => $database_name,
                    'user' => $database_user,
                    'passwd' => $database_pass,
                    'passwd2' => $database_pass,
                )
            );
        } catch (Exception $e) {
            die($e);
        }

        $result = $sock->fetch_result() ?: '';
    }

    /**
     *   Check if folder is empty
     *   or if is already cloned
     *   if not cloned ,empty folder
     * @param string $domain_name
     * @param string $template
     * @param string $domain_path
     **/
    public function emptyFolder(string $domain_name, string $template, string $domain_path)
    {
        $path = "../../../../domains/$domain_name/public_html";
        $dir = shell_exec("ls -la $path") ?: '';

        if (self::str_contains($dir, "snel.app")) {
            //debug
            $cd = "cd $domain_path/$domain_name/public_html";
            echo "<pre>Template cloned already</pre>";
            shell_exec("$cd && git pull 2>&1");
        } else {
            $cd = "cd $domain_path/$domain_name/public_html";

            shell_exec("rm $path/*");
            shell_exec("rm $path/cgi-bin");

            self::cloneTemplate($template, $domain_path, $domain_name);
            shell_exec("$cd && touch snel.app 2>&1");
        }
    }

    /**
     *   clone template to Domain/public_html
     *   and check if it actually did clone
     *   if not cloned ,stop script
     **/
    public function cloneTemplate(string $template, string $domain_path, string $domain_name)
    {
        try {
            $cd = "cd $domain_path/$domain_name/public_html";
            $index = shell_exec("$cd && ls -la") ?: '';

            if (!self::str_contains($index, "app")) {
                shell_exec("$cd && git init 2>&1");
                shell_exec("$cd && git remote add origin $template 2>&1");
                shell_exec("$cd && git fetch 2>&1");
                shell_exec("$cd && git checkout main && git pull 2>&1");

                $dir = shell_exec("ls -la $domain_path/$domain_name/public_html") ?: '';

                if (self::str_contains($dir, "public")) {
                    echo "<pre>Cloned successfully</pre>";
                } else {
                    die("Cloning template failed");
                }
            }

            //debug
            $dir = shell_exec("ls -la $domain_path/$domain_name/public_html");
            echo "<div>$dir</div>";
        } catch (Exeption $e) {
            die($e);
        }
    }

    /**
     *   Creates .env file with database values
     * @param string $domain_path
     * @param string $domain_name
     * @param string $ThemaKleur
     * @param string $LogoLink
     * @param string $LetterType
     * @param string $BedrijfsNaam
     **/
    public function AddTheme(string $domain_path, string $domain_name, string $ThemaKleur, string $LogoLink, string $LetterType, string $BedrijfsNaam)
    {
        $cd = "cd $domain_path/$domain_name/public_html/app/src/extensions";
        $cd2 = "cd $domain_path/$domain_name/public_html/";
        $index = shell_exec("$cd2 && more snel.app") ?: '';

        if (!self::str_contains($index, 'Theme'))
            shell_exec("$cd && echo sed 's/^//DefaultValues.*/`'ThemaKleur' => '$ThemaKleur', \n'LogoLink' => '$LogoLink', \n'LetterType' => '$LetterType', \n'BedrijfsNaam' => '$BedrijfsNaam', \n`/g' SiteConfigExtension.php");
        shell_exec("$cd2 && echo 'Theme' >> snel.app");
    }

    /**
     *   Run composer i && vendor expose
     *
     *   add composer to snel.app so that the script
     *   does not overwrite files
     **/
    public function composer_commands(string $domain_path, string $domain_name)
    {
        $dir = shell_exec("ls -la $domain_path/$domain_name/public_html");
        $cd = "cd $domain_path/$domain_name/public_html";
        $check_conf = shell_exec("$cd && more snel.app") ?: '';

        if (!self::str_contains($check_conf, "composer")) {
            try {
                shell_exec("$cd && composer i 2>&1");
                shell_exec("$cd && echo 'composer' >> snel.app");
                shell_exec("$cd && ls -la 2>&1");

                $cd = "cd $domain_path/$domain_name/public_html";
                $check_dir = shell_exec("$cd && ls -la");

                if (self::str_contains($check_dir, 'composer.lock')) {
                    echo "<pre>composer installed successfully</pre>";
                    echo "<pre>$check_dir</pre>";
                } else {
                    echo "<pre>composer failed to install</pre>";
                }
            } catch (Exeption $e) {
                die($e);
            }
        } else {
            //debug
            echo "<pre>composer already installed</pre>";
            echo "<pre>$check_conf</pre>";
        }
    }

    /**
     *   Creates .env file with database values
     * @param string $domain_path
     * @param string $domain_name
     * @param string $database_user
     * @param string $database_name
     * @param string $database_pass
     **/
    public function create_env(string $domain_path, string $domain_name, string $database_user, string $database_name, string $database_pass)
    {
        $cd = "cd $domain_path/$domain_name/public_html";
        $index = shell_exec("$cd && more .env");

        if (!self::str_contains($index, "env")) {
            shell_exec("$cd && touch .env");

            /**
             *   This is misplaced intentional.
             *   To keep the original ENV structure
             **/
            shell_exec("$cd &&

echo '
# For a complete list of core environment variables see C
# https://docs.silverstripe.org/en/4/getting_started/environment_management/#core-environment-variables \r

# DB \r
SS_DATABASE_CLASS='MySQLDatabase' \r
SS_DATABASE_SERVER='localhost' \r
SS_DATABASE_USERNAME=sneleenweb_$database_user \r
SS_DATABASE_PASSWORD=$database_pass \r
SS_DATABASE_NAME=sneleenweb_$database_name \r
SS_DEFAULT_ADMIN_USERNAME=dima \r
SS_DEFAULT_ADMIN_PASSWORD=dimaterra\r
SS_ERROR_LOG=/silverstripe.log \r
SS_ENVIRONMENT_TYPE=dev' > .env");

            shell_exec("$cd && echo 'env' >> snel.app");
        }
    }

    /**
     *   Inserts template data into the database from sql file
     * @param string $domain_path
     * @param string $domain_name
     * @param string $database_user
     * @param string $database_name
     * @param string $database_pass
     **/
    public function inject_sql(string $domain_path, string $domain_name, string $database_user, string $database_name, string $database_pass, $user_name, $user_pass)
    {
        $cd = "cd $domain_path/$domain_name/public_html";
        $index = shell_exec("$cd && ls -la");
        $app = shell_exec("$cd && more snel.app");

        if (self::str_contains($index, "db.sql") and !self::str_contains($app, "sql")) {
            $inject = shell_exec("$cd && mysql
                --user='sneleenweb_$database_user'
                --database='sneleenweb_$database_name'
                --password='$database_pass' < db.sql 2>&1");

            echo "<pre>$inject $index</pre>";
            shell_exec("$cd && echo 'sql' >> snel.app");
        }
    }

    /**
     *   Runs Dev/build command from silverstripe
     * @param string $domain_path
     * @param string $domain_name
     **/
    public function dev_build(string $domain_path, string $domain_name)
    {
        $cd = "cd $domain_path/$domain_name/public_html";
        $index = shell_exec("$cd && more snel.app");

        if (!self::str_contains($index, "build")) {
            shell_exec("$cd && git restore .");
            shell_exec("$cd && php vendor/silverstripe/framework/cli-script.php dev/build");
            shell_exec("$cd && echo 'build' >> snel.app");
        }
    }

    /**
     *   Installs NPM packages and builds frontend using Gulp.js
     **/
    public function npm_build($domain_path, $domain_name)
    {
        $cd = "cd $domain_path/$domain_name/public_html";
        $index = shell_exec($cd . '&& more snel.app');

        if (!self::str_contains($index, 'npm')) {
            shell_exec("$cd/themes/template && npm install");
            sleep(9);
            shell_exec("$cd/themes/template && npm run build");
            sleep(6);
            shell_exec("$cd/themes/template && ^C ");
        }

        if (self::str_contains(shell_exec("$cd/themes/template ls -la"), 'dist')) {
            shell_exec("$cd && echo 'npm' >> snel.app");
        } else {
//                self::npm_build($domain_path,$domain_name);
        }

    }

    /**
     *   Run composer i && vendor expose
     *   add composer to snel.app so that the script
     *   does not overwrite files
     **/
    public function composer_vendor_expose($domain_path, $domain_name)
    {
        $dir = shell_exec("ls -la $domain_path/$domain_name/public_html");
        $cd = "cd $domain_path/$domain_name/public_html";
        $check_conf = shell_exec("$cd && more snel.app");

        try {
            shell_exec("$cd && composer vendor-expose 2>&1");
            shell_exec("$cd && echo 'vendor-expose' >> snel.app");
            echo "<pre>" . shell_exec("$cd/themes/template/dist && ls -la") . "</pre>";
        } catch (Exeption $e) {
            die($e);
        }
    }

    public function Email(array $data = []): string
    {
        $data = [
            'demo_domain' => 'dima.dimademo.nl',
            'demo_email' => 'dion@dima.nl',
            'demo_password' => 'gst7usfts&&%YWGhW@',
            'customer_company_name' => 'Company',
            'customer_domain' => 'Company.nl',
            'customer_email' => 'dion@dima.nl',
            'customer_name' => 'dion kempenk',
        ];

        return Mail::to($data['customer_email'])
            ->send(new MailService($data))
            ->toString();
    }
}
