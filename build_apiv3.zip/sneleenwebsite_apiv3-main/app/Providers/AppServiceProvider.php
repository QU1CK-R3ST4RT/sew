<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;
use Laravel\Passport\Passport;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //set encryption key storage path
        Passport::loadKeysFrom(app_path().'/secrets/oauth');

        //set expiration to 1 hour
        Passport::tokensExpireIn(now()->addMinutes(60));

        //set to use password grant
        Passport::enablePasswordGrant();

        //Fillament now guards existing models
        Model::unguard();

        Gate::define('viewPulse', function (User $user) {
            return $user->isAdmin();
        });
    }
}
