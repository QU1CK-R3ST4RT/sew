<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <style>

        [x-cloak] {
            display: none !important;
        }

        pre {
            padding: 20px;
            border-radius: 20px;
        }

        body {
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
        }

        h1 {
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            font-weight: bold;
        }

        .container {
            max-width: 1300px;
        }

        section {
            display:flex;
            justify-content: center;
        }

        td,th {
            text-align: left;
        }

        table {
            width: 100%;

        }

        table {
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            border-collapse: collapse;
            border: 1px solid white;
            border-radius: 20px;
            overflow:hidden;
        }
        th {
            border-collapse: collapse;
            padding:20px;
            background-color: white;
            color:#24292e;
        }
        td {

            /*border-left: 1px solid black;*/
            border-bottom: 1px solid #e1e1e1;
            padding:20px;
            border-collapse: collapse;
            color: white;
        }
        a {
            text-align: center;
        }

        #body-1 {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            position: relative;
            width: 100%;
            padding-left: 1.5rem;
            padding-right: 1.5rem;
            max-width: 80rem;
        }

        #body-main {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            margin-top: 1.5rem;
        }

        #body-2 {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            display: flex;
            align-items: flex-start;
            gap: 1rem;
            border-radius: 0.5rem;
            padding: 1.5rem;
            box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
            transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-text-decoration-color, -webkit-backdrop-filter;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 300ms;
            padding-bottom: 2.5rem;
            --tw-bg-opacity: 1;
            background-color: rgb(24 24 27);
        }

        #body-3 {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            display: flex;
            flex-shrink: 0;
            align-items: center;
            justify-content: center;
            border-radius: 9999px;
            background-color: rgb(255 45 32 / 0.1);
            width: 4rem;
            height: 4rem;
        }

        #body-4 {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            padding-top: 1.25rem;
        }

        #body-h2 {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            margin: 0;
            font-size: 1.25rem;
            line-height: 1.75rem;
            font-weight: 600;
            --tw-text-opacity: 1;
            color: rgb(255 255 255);
        }

        #body-p {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            margin: 0;
            margin-top: 1rem;
            font-size: 0.875rem;
            line-height: 1.625;
        }

        #body-svg {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            line-height: inherit;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            color: rgb(255 255 255 / 0.5);
            fill: none;
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            display: block;
            vertical-align: middle;
            width: 1.5rem;
            height: 1.5rem;
        }

        #body-footer {
            -webkit-text-size-adjust: 100%;
            tab-size: 4;
            font-feature-settings: normal;
            font-variation-settings: normal;
            -webkit-tap-highlight-color: transparent;
            font-family: Figtree, ui-sans-serif, system-ui, sans-serif, Apple Color Emoji, Segoe UI Emoji, Segoe UI Symbol, Noto Color Emoji;
            -webkit-font-smoothing: antialiased;
            box-sizing: border-box;
            border-width: 0;
            border-style: solid;
            border-color: #e5e7eb;
            padding-top: 4rem;
            padding-bottom: 4rem;
            text-align: center;
            font-size: 0.875rem;
            line-height: 1.25rem;
            --tw-text-opacity: 1;
            color: rgb(255 255 255 / 0.7);
        }
    </style>
</head>

<body>
    <br>
    <br>



    <div id="body-1" class="relative w-full max-w-2xl px-6 lg:max-w-7xl" style="margin: 0 auto; width: 80%;">
        <main id="body-main" class="mt-6" style="display: flex; justify-content: center">
            <div id="body-2" class="flex items-start gap-4 rounded-lg bg-white p-6 shadow-[0px_14px_34px_0px_rgba(0,0,0,0.08)] ring-1 ring-white/[0.05] transition duration-300 hover:text-black/70 hover:ring-black/20 focus:outline-none focus-visible:ring-[#FF2D20] lg:pb-10 dark:bg-zinc-900 dark:ring-zinc-800 dark:hover:text-white/70 dark:hover:ring-zinc-700 dark:focus-visible:ring-[#FF2D20]">
                <div id="body-3" class="flex size-12 shrink-0 items-center justify-center rounded-full bg-[#FF2D20]/10 sm:size-16">
                    <svg id="body-svg" class="size-5 sm:size-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><g fill="#FF2D20"><path d="M16.597 12.635a.247.247 0 0 0-.08-.237 2.234 2.234 0 0 1-.769-1.68c.001-.195.03-.39.084-.578a.25.25 0 0 0-.09-.267 8.8 8.8 0 0 0-4.826-1.66.25.25 0 0 0-.268.181 2.5 2.5 0 0 1-2.4 1.824.045.045 0 0 0-.045.037 12.255 12.255 0 0 0-.093 3.86.251.251 0 0 0 .208.214c2.22.366 4.367 1.08 6.362 2.118a.252.252 0 0 0 .32-.079 10.09 10.09 0 0 0 1.597-3.733ZM13.616 17.968a.25.25 0 0 0-.063-.407A19.697 19.697 0 0 0 8.91 15.98a.25.25 0 0 0-.287.325c.151.455.334.898.548 1.328.437.827.981 1.594 1.619 2.28a.249.249 0 0 0 .32.044 29.13 29.13 0 0 0 2.506-1.99ZM6.303 14.105a.25.25 0 0 0 .265-.274 13.048 13.048 0 0 1 .205-4.045.062.062 0 0 0-.022-.07 2.5 2.5 0 0 1-.777-.982.25.25 0 0 0-.271-.149 11 11 0 0 0-5.6 2.815.255.255 0 0 0-.075.163c-.008.135-.02.27-.02.406.002.8.084 1.598.246 2.381a.25.25 0 0 0 .303.193 19.924 19.924 0 0 1 5.746-.438ZM9.228 20.914a.25.25 0 0 0 .1-.393 11.53 11.53 0 0 1-1.5-2.22 12.238 12.238 0 0 1-.91-2.465.248.248 0 0 0-.22-.187 18.876 18.876 0 0 0-5.69.33.249.249 0 0 0-.179.336c.838 2.142 2.272 4 4.132 5.353a.254.254 0 0 0 .15.048c1.41-.01 2.807-.282 4.117-.802ZM18.93 12.957l-.005-.008a.25.25 0 0 0-.268-.082 2.21 2.21 0 0 1-.41.081.25.25 0 0 0-.217.2c-.582 2.66-2.127 5.35-5.75 7.843a.248.248 0 0 0-.09.299.25.25 0 0 0 .065.091 28.703 28.703 0 0 0 2.662 2.12.246.246 0 0 0 .209.037c2.579-.701 4.85-2.242 6.456-4.378a.25.25 0 0 0 .048-.189 13.51 13.51 0 0 0-2.7-6.014ZM5.702 7.058a.254.254 0 0 0 .2-.165A2.488 2.488 0 0 1 7.98 5.245a.093.093 0 0 0 .078-.062 19.734 19.734 0 0 1 3.055-4.74.25.25 0 0 0-.21-.41 12.009 12.009 0 0 0-10.4 8.558.25.25 0 0 0 .373.281 12.912 12.912 0 0 1 4.826-1.814ZM10.773 22.052a.25.25 0 0 0-.28-.046c-.758.356-1.55.635-2.365.833a.25.25 0 0 0-.022.48c1.252.43 2.568.65 3.893.65.1 0 .2 0 .3-.008a.25.25 0 0 0 .147-.444c-.526-.424-1.1-.917-1.673-1.465ZM18.744 8.436a.249.249 0 0 0 .15.228 2.246 2.246 0 0 1 1.352 2.054c0 .337-.08.67-.23.972a.25.25 0 0 0 .042.28l.007.009a15.016 15.016 0 0 1 2.52 4.6.25.25 0 0 0 .37.132.25.25 0 0 0 .096-.114c.623-1.464.944-3.039.945-4.63a12.005 12.005 0 0 0-5.78-10.258.25.25 0 0 0-.373.274c.547 2.109.85 4.274.901 6.453ZM9.61 5.38a.25.25 0 0 0 .08.31c.34.24.616.561.8.935a.25.25 0 0 0 .3.127.631.631 0 0 1 .206-.034c2.054.078 4.036.772 5.69 1.991a.251.251 0 0 0 .267.024c.046-.024.093-.047.141-.067a.25.25 0 0 0 .151-.23A29.98 29.98 0 0 0 15.957.764a.25.25 0 0 0-.16-.164 11.924 11.924 0 0 0-2.21-.518.252.252 0 0 0-.215.076A22.456 22.456 0 0 0 9.61 5.38Z"/></g></svg>
                </div>

                <div id="body-4" class="pt-3 sm:pt-5">
                    <h2 id="body-h2" class="text-xl font-semibold text-black dark:text-white">Snelle Website Api</h2>

                    <p id="body-p" class="mt-4 text-sm/relaxed">
                        Uw website {{ $demo_domain }} staat klaar om te vullen. bent u klaar met vullen? stuur dan gerust een mail dan zetten wij hem live op het gewenste domein.
                    </p>

                    <br>

                    <h3 style="color: white;">Inlog gegevens</h3>
                    <div style="background-color: rgb(67,67,72); border: transparent; border-radius: 15px; padding: 15px; margin-bottom: 20px;">
                        <div style="float:left; text-align: center; border-right: solid white 1px; padding: 10px; margin-right: 10px;">
                            <h4 style="font-weight: bold; margin:0; border-bottom: white 1px; color: white;"> Url </h4>
                        </div>
                        <div style="padding: 10px 0 10px 30px;">
                            <p style="margin: 0;"><b><a href="{{ $demo_domain }}" style="color:unset; text-decoration: none; text-underline: none;">{{ $demo_domain }}</a></b></p>
                            <p style="margin: 0;">De url om in te loggen op het cms</p>
                        </div>
                    </div>

                    <div style="background-color: rgb(67,67,72); border: transparent; border-radius: 15px; padding: 15px; margin-bottom: 20px;">
                        <div style="float:left; text-align: center; border-right: solid white 1px; padding: 10px; margin-right: 10px;">
                            <h4 style="font-weight: bold; margin:0; border-bottom: white 1px; color: white;"> Email </h4>
                        </div>
                        <div style="padding: 10px 0 10px 30px;">
                            <p style="margin: 0;"><b>{{ $demo_email }}</b></p>
                            <p style="margin: 0;">Email om in te loggen op het cms</p>
                        </div>
                    </div>

                    <div style="background-color: rgb(67,67,72); border: transparent; border-radius: 15px; padding: 15px; margin-bottom: 20px;">
                        <div style="float:left; text-align: center; border-right: solid white 1px; padding: 10px; margin-right: 10px;">
                            <h4 style="font-weight: bold; margin:0; border-bottom: white 1px; color: white;"> Wachtwoord </h4>
                        </div>
                        <div style="padding: 10px 0 10px 30px;">
                            <p style="margin: 0;"><b>{{ $demo_password }}</b></p>
                            <p style="margin: 0;">Email om in te loggen op het cms</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
