<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">

    <meta name="application-name" content="{{ config('app.name') }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ config('app.name') }}</title>

    <style>
        [x-cloak] {
            display: none !important;
        }

        pre {
            padding: 20px;
            border-radius: 20px;
        }

        body {
            font-family: "Helvetica", "Arial", sans-serif;
        }

        .container {
            max-width: 1300px;
        }

        section {
            display:flex;
            justify-content: center;
        }

        hr {
            color: rgba(0, 0, 0, 0.62);
            height: 1px;
            border-radius: 1px;
            background: rgba(0, 0, 0, 0.62);
        }
        td,th {
            text-align: left;
        }

        table {
            width: 100%;

        }

        table {
            border-collapse: collapse;
            border: 1px solid white;
            border-radius: 20px;
            overflow:hidden;
        }
        th {
            border-collapse: collapse;
            padding:20px;
            background-color: #24292e;
            color:white;
        }
        td {

            /*border-left: 1px solid black;*/
            border-bottom: 1px solid #e1e1e1;
            padding:20px;
            border-collapse: collapse;
        }
    </style>

</head>
<body>
    <section>
        <div class="container">
<x-markdown theme="github-dark">


<br>


# About SnelEenWebsite API

- Creates websites with directadmin-api
- Uses templates from git
</x-markdown>
            <br>
            <br>
            <br>
            <br>

            <h1>Endpoints Api</h1>
            <table>
                <tr style="border-radius: 20px; border: 1px white;">
                    <th>Endpoint</th>
                    <th>Type</th>
                    <th>Resource</th>
                    <th>Protection</th>
                </tr>
                <tr>
                    <td>oath/token</td>
                    <td><b>Post</b></td>
                    <td>-</td>
                    <td>
                        Username <br>
                        Password <br>
                        Client ID <br>
                        Client Secret <br>
                    </td>
                </tr>
                <tr>
                    <td>api/task</td>
                    <td><b>Post</b></td>
                    <td>Task</td>
                    <td>Bearer</td>
                </tr>
                <tr>
                    <td>api/user</td>
                    <td><b>Get</b></td>
                    <td>User</td>
                    <td>Login</td>
                </tr>
            </table>

            <br>
            <br>
            <br>
            <br>

            <h1>Endpoints Web</h1>
            <table>
                <tr style="border-radius: 20px; border: 1px white;">
                    <th>Endpoint</th>
                    <th>Protection</th>
                    <th>Description</th>
                </tr>
                <tr>
                    <td>/</td>
                    <td><b>-</b></td>
                    <td>Welcome page</td>
                </tr>
                <tr>
                    <td>/endpoints</td>
                    <td><b>Login</b></td>
                    <td>Endpoints and documentation</td>
                </tr>
            </table>

            <br>
            <br>
            <br>
            <br>
<x-markdown theme="github-dark">


<br>
<br>
<br>
<br>

# Documentation

<hr>

# Setup
1. ### Run ``install:api`` to run necessary database migrations.
    ```shell
    php artisan install:api --passport
    ```

<br>

2. ### Run ```passport:keys``` to generate the encryption keys.
    ```shell
    php artisan passport:keys
    ```

<br>

3. ### Create a User with ```Tinker```
    1. **Start Tinker**
        ``php artisan tinker``


    2. **Paste the following**
        ```php
        $user = new User();
        $user->name = '<name>';
        $user->password = Hash::make('<password>');
        $user->email = '<email>';
        $user->save();
        ```

<br>

# Authorization
1. ### Simply send a post request to ``{domain}/oauth/token`` with this required parameters in the ``raw body``.
    after the post request you will get back a bearer_token and a refresh_token
    ```json
    {
        "grant_type": "password",
        "client_id": "{ Passport Client ID }",
        "client_secret": "{ Passport Client Secret }",
        "username": "{ Laravel User Email }",
        "password": "{ Laravel User Password }",
        "scope": "*"
    }
    ```
    be sure to add it to the session to prevent exposing your login details and to prevent the api to flood with inactive bearer-tokens.

<br>

2. ### In order to send data to the API you will need to put the token in the request headers
    ```php
    $headers = [
      'Accept' => 'application/json',
      'Content-Type' => 'application/json',
      'Authorization' => 'Bearer { token }'
    ]
    ```
<br>

# Usage
### Endpoint api/task
with the post request send this in the body and the task will be queued
```json
{
  "Data": {
      "domain":"dima.nl",
      "orderID":"13531",
      "client":"Dion | Dima",
      "email":"dion@dima.nl",
      "phone":"0612345678",
      "template-url":"git.com/dima-support"
  }
}
```
</x-markdown>
        </div>
    </section>
</body>
</html>

